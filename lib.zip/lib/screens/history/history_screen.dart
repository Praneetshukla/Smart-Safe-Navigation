// lib/screens/history/history_screen.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import '../../models/models.dart';
import '../../services/journey_service.dart';
import '../../services/auth_service.dart';
import '../../services/pdf_export_service.dart';
import '../../utils/app_theme.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final _journeySvc = JourneyService();
  final _authSvc = AuthService();
  final _pdfSvc = PdfExportService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primary,
      body: SafeArea(
        child: FutureBuilder(
          future: _authSvc.getCurrentAppUser(),
          builder: (ctx, userSnap) {
            final user = userSnap.data;
            if (userSnap.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator(color: AppTheme.accent));
            }
            if (user == null) {
              return Center(child: Text('Sign in to view history', style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary)));
            }
            return CustomScrollView(
              slivers: [
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                    child: Row(
                      children: [
                        Text('Journey History', style: GoogleFonts.spaceGrotesk(color: AppTheme.textPrimary, fontSize: 24, fontWeight: FontWeight.w700)),
                        const Spacer(),
                        StreamBuilder<List<Journey>>(
                          stream: _journeySvc.streamUserJourneys(user.uid),
                          builder: (_, jSnap) {
                            final journeys = jSnap.data ?? [];
                            return FutureBuilder<Map<String, dynamic>>(
                              future: _journeySvc.getJourneyStats(user.uid),
                              builder: (_, statsSnap) {
                                return IconButton(
                                  onPressed: journeys.isEmpty ? null : () => _pdfSvc.exportJourneyReport(journeys: journeys, stats: statsSnap.data ?? {}, context: context),
                                  icon: const Icon(Icons.picture_as_pdf_outlined, color: AppTheme.accentOrange),
                                  tooltip: 'Export PDF',
                                );
                              },
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: FutureBuilder<Map<String, dynamic>>(
                    future: _journeySvc.getJourneyStats(user.uid),
                    builder: (_, snap) {
                      if (!snap.hasData) return const SizedBox(height: 100, child: Center(child: CircularProgressIndicator(color: AppTheme.accent)));
                      return _StatsSection(stats: snap.data!);
                    },
                  ),
                ),
                StreamBuilder<List<Journey>>(
                  stream: _journeySvc.streamUserJourneys(user.uid),
                  builder: (ctx, snap) {
                    final journeys = snap.data ?? [];
                    if (snap.connectionState == ConnectionState.waiting) {
                      return const SliverToBoxAdapter(child: Center(child: Padding(padding: EdgeInsets.all(32), child: CircularProgressIndicator(color: AppTheme.accent))));
                    }
                    if (journeys.isEmpty) {
                      return SliverToBoxAdapter(
                        child: Padding(
                          padding: const EdgeInsets.all(40),
                          child: Center(child: Column(children: [
                            const Icon(Icons.route_outlined, color: AppTheme.textSecondary, size: 56),
                            const SizedBox(height: 12),
                            Text('No journeys yet', style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 15)),
                            const SizedBox(height: 6),
                            Text('Start navigating to see your history', style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 13)),
                          ])),
                        ),
                      );
                    }
                    return SliverList(
                      delegate: SliverChildBuilderDelegate(
                        (_, i) {
                          if (i == 0) return Padding(padding: const EdgeInsets.fromLTRB(20, 20, 20, 8), child: Text('Recent Journeys', style: GoogleFonts.spaceGrotesk(color: AppTheme.textPrimary, fontWeight: FontWeight.w700, fontSize: 16)));
                          return Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 10), child: _JourneyCard(journey: journeys[i - 1]));
                        },
                        childCount: journeys.length + 1,
                      ),
                    );
                  },
                ),
                const SliverToBoxAdapter(child: SizedBox(height: 80)),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _StatsSection extends StatelessWidget {
  final Map<String, dynamic> stats;
  const _StatsSection({required this.stats});

  @override
  Widget build(BuildContext context) {
    final routeTypes = stats['routeTypes'] as Map<String, int>? ?? {};
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        Row(children: [
          Expanded(child: _StatCard(label: 'Total', value: stats['total'].toString(), icon: Icons.route_rounded, color: AppTheme.accent)),
          const SizedBox(width: 10),
          Expanded(child: _StatCard(label: 'This Week', value: (stats['thisWeek'] ?? 0).toString(), icon: Icons.today_rounded, color: AppTheme.accentYellow)),
          const SizedBox(width: 10),
          Expanded(child: _StatCard(label: 'Avg Rating', value: (stats['avgRating'] as double?)?.toStringAsFixed(1) ?? '—', icon: Icons.star_rounded, color: AppTheme.accentOrange)),
        ]),
        if (routeTypes.isNotEmpty) ...[
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: AppTheme.cardBg, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppTheme.border)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Route Preferences', style: GoogleFonts.spaceGrotesk(color: AppTheme.textPrimary, fontWeight: FontWeight.w700, fontSize: 14)),
              const SizedBox(height: 16),
              SizedBox(
                height: 140,
                child: PieChart(PieChartData(
                  sections: routeTypes.entries.map((e) {
                    final colors = {'safest': AppTheme.safe, 'fastest': AppTheme.accentOrange, 'balanced': AppTheme.accent};
                    return PieChartSectionData(value: e.value.toDouble(), color: colors[e.key] ?? AppTheme.textSecondary, title: e.key, titleStyle: GoogleFonts.spaceGrotesk(fontSize: 10, fontWeight: FontWeight.w700, color: Colors.white), radius: 50);
                  }).toList(),
                  sectionsSpace: 2, centerSpaceRadius: 30,
                )),
              ),
            ]),
          ),
        ],
      ]),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final Color color;
  const _StatCard({required this.label, required this.value, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppTheme.cardBg, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppTheme.border)),
      child: Column(children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(height: 8),
        Text(value, style: GoogleFonts.spaceGrotesk(color: AppTheme.textPrimary, fontSize: 20, fontWeight: FontWeight.w800)),
        const SizedBox(height: 2),
        Text(label, textAlign: TextAlign.center, style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 10)),
      ]),
    );
  }
}

class _JourneyCard extends StatelessWidget {
  final Journey journey;
  const _JourneyCard({required this.journey});

  @override
  Widget build(BuildContext context) {
    final routeColors = {'safest': AppTheme.safe, 'fastest': AppTheme.accentOrange, 'balanced': AppTheme.accent};
    final color = routeColors[journey.routeType] ?? AppTheme.accent;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: AppTheme.cardBg, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppTheme.border)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 8),
          Text(AppConstants.routeTypeLabels[journey.routeType] ?? journey.routeType, style: GoogleFonts.spaceGrotesk(color: color, fontSize: 11, fontWeight: FontWeight.w700)),
          const Spacer(),
          Text(DateFormat('MMM d, h:mm a').format(journey.startTime), style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 11)),
        ]),
        const SizedBox(height: 10),
        Row(children: [Icon(Icons.radio_button_checked_rounded, color: AppTheme.safe, size: 14), const SizedBox(width: 8), Expanded(child: Text(journey.startAddress, overflow: TextOverflow.ellipsis, style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 12)))]),
        const SizedBox(height: 4),
        Row(children: [Icon(Icons.location_on_rounded, color: AppTheme.accentOrange, size: 14), const SizedBox(width: 8), Expanded(child: Text(journey.endAddress, overflow: TextOverflow.ellipsis, style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 12)))]),
        if (journey.rating != null) ...[
          const SizedBox(height: 10),
          Row(children: [
            RatingBarIndicator(rating: journey.rating!, itemBuilder: (_, __) => const Icon(Icons.star, color: AppTheme.accentYellow), itemCount: 5, itemSize: 14),
            const SizedBox(width: 6),
            Text(journey.rating!.toStringAsFixed(1), style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 11)),
          ]),
        ],
      ]),
    );
  }
}
