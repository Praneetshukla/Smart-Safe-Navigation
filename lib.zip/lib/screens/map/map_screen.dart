import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/models.dart';
import '../../services/location_service.dart';
import '../../services/route_service.dart';
import '../../services/safety_service.dart';
// import '../../services/tts_service.dart';
import '../../services/auth_service.dart';
import '../../services/journey_service.dart';
import '../../utils/app_theme.dart';
import '../../widgets/route_panel.dart';
import '../../widgets/hazard_marker.dart';
import '../reports/add_report_screen.dart';

// ─────────────────────────────────────────────────────────────────────────────
//  Route colour palette — one distinct colour per route slot
// ─────────────────────────────────────────────────────────────────────────────
const _routeColors = [
  Color(0xFF00E676), // slot 0 – safest   → vivid green
  Color(0xFF2979FF), // slot 1 – balanced → electric blue
  Color(0xFFFF6D00), // slot 2 – fastest  → deep orange
];

const _routeLabels = ['Safest', 'Balanced', 'Fastest'];
const _routeIcons  = [Icons.shield_rounded, Icons.balance_rounded, Icons.flash_on_rounded];

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});
  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> with TickerProviderStateMixin {
  // ── Services ────────────────────────────────────────────────────────────────
  final _mapController = MapController();
  final _locationSvc   = LocationService();
  final _routeSvc      = RouteService();
  final _safetySvc     = SafetyService();
  final _ttsSvc        = TtsService();
  final _journeySvc    = JourneyService();
  final _authSvc       = AuthService();

  // ── State ───────────────────────────────────────────────────────────────────
  LatLng? _currentLocation;
  LatLng? _origin;          // user-typed source
  LatLng? _destination;
  String  _originAddress      = '';
  String  _destinationAddress = '';

  List<SafeRoute>       _routes       = [];
  SafeRoute?            _selectedRoute;
  List<SafetyReport>    _reports      = [];
  StreamSubscription<LatLng>?          _locationSub;
  StreamSubscription<List<SafetyReport>>? _reportsSub;

  bool   _isNavigating  = false;
  bool   _isLoading     = false;
  bool   _showRoutePanel = false;
  // Phase: 'search' = show source/dest form, 'map' = show map+routes
  String _phase         = 'search';

  double _areaSafetyScore = 8.5;
  String? _activeJourneyId;

  // Animation for panel slide-up
  late AnimationController _panelCtrl;
  late Animation<Offset>   _panelAnim;

  // ── Source/dest text controllers ────────────────────────────────────────────
  final _srcCtrl  = TextEditingController();
  final _dstCtrl  = TextEditingController();
  bool _srcLoading = false;
  bool _dstLoading = false;

  @override
  void initState() {
    super.initState();
    _panelCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _panelAnim = Tween<Offset>(begin: const Offset(0, 1), end: Offset.zero)
        .animate(CurvedAnimation(parent: _panelCtrl, curve: Curves.easeOutCubic));
    _initLocation();
  }

  @override
  void dispose() {
    _locationSub?.cancel();
    _reportsSub?.cancel();
    _ttsSvc.stop();
    _panelCtrl.dispose();
    _srcCtrl.dispose();
    _dstCtrl.dispose();
    super.dispose();
  }

  // ── Init GPS ─────────────────────────────────────────────────────────────────
  Future<void> _initLocation() async {
    final loc = await _locationSvc.getCurrentLocation();
    if (loc != null && mounted) {
      setState(() => _currentLocation = loc);
      // Auto-fill source with current address
      final addr = await _locationSvc.getAddressFromLatLng(loc);
      if (mounted) {
        setState(() {
          _origin        = loc;
          _originAddress = addr;
          _srcCtrl.text  = addr;
        });
      }
      _loadNearbyReports(loc);
      _loadAreaSafety(loc);
    }
  }

  void _loadNearbyReports(LatLng center) {
    _reportsSub?.cancel();
    _reportsSub = _safetySvc.streamNearbyReports(center).listen((r) {
      if (mounted) setState(() => _reports = r);
    });
  }

  Future<void> _loadAreaSafety(LatLng loc) async {
    final score = await _safetySvc.getAreaSafetyScore(loc);
    if (mounted) setState(() => _areaSafetyScore = score);
  }

  // ── Geocode helpers ──────────────────────────────────────────────────────────
  Future<void> _resolveSource(String query) async {
    setState(() => _srcLoading = true);
    final loc = await _locationSvc.getLatLngFromAddress(query);
    setState(() { _srcLoading = false; });
    if (loc == null) { _snack('Source location not found'); return; }
    setState(() { _origin = loc; _originAddress = query; });
  }

  Future<void> _resolveDestination(String query) async {
    setState(() => _dstLoading = true);
    final loc = await _locationSvc.getLatLngFromAddress(query);
    setState(() { _dstLoading = false; });
    if (loc == null) { _snack('Destination not found'); return; }
    setState(() { _destination = loc; _destinationAddress = query; });
  }

  // ── Find Routes ──────────────────────────────────────────────────────────────
  Future<void> _findRoutes() async {
    if (_srcCtrl.text.isNotEmpty && _origin == null) {
      await _resolveSource(_srcCtrl.text.trim());
    }
    if (_dstCtrl.text.isNotEmpty && _destination == null) {
      await _resolveDestination(_dstCtrl.text.trim());
    }

    if (_origin == null || _destination == null) {
      _snack('Please set both source and destination');
      return;
    }

    setState(() { _isLoading = true; _phase = 'map'; });

    // Move map to show origin
    _mapController.move(_origin!, 13);
    _loadNearbyReports(_origin!);

    final routes = await _routeSvc.getRoutes(_origin!, _destination!, _reports);

    // Ensure we have exactly 3 slots (pad with variants if fewer returned)
    final padded = _padRoutes(routes);

    if (mounted) {
      setState(() {
        _routes        = padded;
        _selectedRoute = padded.isNotEmpty ? padded.first : null;
        _showRoutePanel = true;
        _isLoading     = false;
      });
      _panelCtrl.forward();
      if (padded.isNotEmpty) _fitAllRoutes(padded);
    }
  }

  /// Ensure 3 routes: Safest / Balanced / Fastest
  List<SafeRoute> _padRoutes(List<SafeRoute> raw) {
    final types   = ['safest', 'balanced', 'fastest'];
    final result  = <SafeRoute>[];

    for (int i = 0; i < 3; i++) {
      final type = types[i];
      SafeRoute? found;
      try { found = raw.firstWhere((r) => r.type == type); } catch (_) {}

      if (found != null) {
        result.add(found);
      } else if (raw.isNotEmpty) {
        // Clone first route with modified type/score to fill the slot
        final base = raw.first;
        result.add(SafeRoute(
          id:              '${type}_generated',
          type:            type,
          points:          base.points,
          distanceKm:      base.distanceKm * (1 + i * 0.08),
          durationMinutes: (base.durationMinutes * (1 - i * 0.07)).ceil(),
          safetyScore:     (base.safetyScore - i * 1.2).clamp(1, 10),
          hazardWarnings:  i > 0 ? [...base.hazardWarnings, if (i == 2) 'Faster but less safe'] : base.hazardWarnings,
        ));
      }
    }
    return result;
  }

  void _fitAllRoutes(List<SafeRoute> routes) {
    final allPts = routes.expand((r) => r.points).toList();
    if (allPts.isEmpty) return;
    double minLat = allPts.first.latitude,  maxLat = allPts.first.latitude;
    double minLng = allPts.first.longitude, maxLng = allPts.first.longitude;
    for (final p in allPts) {
      if (p.latitude  < minLat) minLat = p.latitude;
      if (p.latitude  > maxLat) maxLat = p.latitude;
      if (p.longitude < minLng) minLng = p.longitude;
      if (p.longitude > maxLng) maxLng = p.longitude;
    }
    _mapController.move(LatLng((minLat + maxLat) / 2, (minLng + maxLng) / 2), 12);
  }

  // ── Navigation ────────────────────────────────────────────────────────────────
  Future<void> _startNavigation() async {
    if (_selectedRoute == null) return;
    final user = await _authSvc.getCurrentAppUser();
    if (user != null && _origin != null && _destination != null) {
      final journey = Journey(
        id: '', userId: user.uid,
        startAddress: _originAddress,
        endAddress:   _destinationAddress,
        startLocation: _origin!,
        endLocation:   _destination!,
        startTime: DateTime.now(),
        routeType: _selectedRoute!.type,
      );
      _activeJourneyId = await _journeySvc.startJourney(journey);
    }

    setState(() => _isNavigating = true);
    _locationSub = _locationSvc.trackLocation().listen((loc) {
      if (mounted) {
        setState(() => _currentLocation = loc);
        _mapController.move(loc, 15);
        _checkArrival(loc);
      }
    });

    await _ttsSvc.speak('Navigation started. Heading to $_destinationAddress.');
    if (_selectedRoute!.hazardWarnings.isNotEmpty) {
      await Future.delayed(const Duration(seconds: 2));
      await _ttsSvc.safetyAlert('Watch out for: ${_selectedRoute!.hazardWarnings.join(", ")}');
    }
  }

  void _checkArrival(LatLng current) {
    if (_destination == null) return;
    if (_locationSvc.distanceBetween(current, _destination!) < 0.05) {
      _stopNavigation();
      _ttsSvc.announceArrival(_destinationAddress);
    }
  }

  Future<void> _stopNavigation() async {
    _locationSub?.cancel();
    if (_activeJourneyId != null) _showRatingDialog();
    _panelCtrl.reverse();
    setState(() {
      _isNavigating   = false;
      _showRoutePanel = false;
      _routes         = [];
      _selectedRoute  = null;
      _destination    = null;
      _phase          = 'search';
    });
    await _ttsSvc.stop();
  }

  void _showRatingDialog() {
    showDialog(
      context: context,
      builder: (ctx) {
        double rating = 4;
        return AlertDialog(
          backgroundColor: AppTheme.cardBg,
          title: Text('Rate this route', style: GoogleFonts.spaceGrotesk(color: AppTheme.textPrimary)),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('How safe did this route feel?', style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary)),
            const SizedBox(height: 16),
            StatefulBuilder(builder: (_, setS) => Slider(
              value: rating, min: 1, max: 5, divisions: 4,
              activeColor: AppTheme.accent, label: rating.round().toString(),
              onChanged: (v) => setS(() => rating = v),
            )),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Skip')),
            ElevatedButton(
              onPressed: () async {
                await _journeySvc.completeJourney(_activeJourneyId!, rating: rating);
                _activeJourneyId = null;
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('Submit'),
            ),
          ],
        );
      },
    );
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: AppTheme.cardBg));
  }

  // ─────────────────────────────────────────────────────────────────────────────
  //  BUILD
  // ─────────────────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primary,
      body: _phase == 'search' ? _buildSearchPhase() : _buildMapPhase(),
    );
  }

  // ── Phase 1 : Source & Destination Form ──────────────────────────────────────
  Widget _buildSearchPhase() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [AppTheme.primary, Color(0xFF0D2137)],
        ),
      ),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SizedBox(height: 12),
            // Header
            Row(children: [
              Container(
                width: 44, height: 44,
                decoration: BoxDecoration(
                  color: AppTheme.accent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.accent, width: 1.5),
                ),
                child: const Icon(Icons.shield_rounded, color: AppTheme.accent, size: 24),
              ),
              const SizedBox(width: 12),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('SafeRoute', style: GoogleFonts.spaceGrotesk(color: AppTheme.textPrimary, fontSize: 22, fontWeight: FontWeight.w800)),
                Text('Navigate safely', style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 12)),
              ]),
            ]),

            const SizedBox(height: 40),
            Text('Where are you going?', style: GoogleFonts.spaceGrotesk(color: AppTheme.textPrimary, fontSize: 26, fontWeight: FontWeight.w700, height: 1.2)),
            const SizedBox(height: 6),
            Text('Enter your source and destination to find the safest route.',
                style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 13)),

            const SizedBox(height: 36),

            // ── Source / Destination Card ───────────────────────────────────────
            Container(
              decoration: BoxDecoration(
                color: AppTheme.cardBg,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppTheme.border),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.25), blurRadius: 20, offset: const Offset(0, 8))],
              ),
              child: Column(children: [
                // Source
                _LocationField(
                  controller: _srcCtrl,
                  label: 'From',
                  hint: 'Your current location',
                  icon: Icons.radio_button_checked_rounded,
                  iconColor: AppTheme.safe,
                  isLoading: _srcLoading,
                  isFirst: true,
                  onChanged: (v) { _origin = null; },
                  onSubmitted: (v) { if (v.isNotEmpty) _resolveSource(v); },
                  onUseGps: () async {
                    setState(() => _srcLoading = true);
                    final loc = await _locationSvc.getCurrentLocation();
                    if (loc != null) {
                      final addr = await _locationSvc.getAddressFromLatLng(loc);
                      setState(() { _origin = loc; _originAddress = addr; _srcCtrl.text = addr; });
                    }
                    setState(() => _srcLoading = false);
                  },
                ),
                // Divider with swap
                _SwapDivider(onSwap: () {
                  final tmpCtrl  = _srcCtrl.text;
                  final tmpLoc   = _origin;
                  final tmpAddr  = _originAddress;
                  setState(() {
                    _srcCtrl.text       = _dstCtrl.text;
                    _origin             = _destination;
                    _originAddress      = _destinationAddress;
                    _dstCtrl.text       = tmpCtrl;
                    _destination        = tmpLoc;
                    _destinationAddress = tmpAddr;
                  });
                }),
                // Destination
                _LocationField(
                  controller: _dstCtrl,
                  label: 'To',
                  hint: 'Enter destination',
                  icon: Icons.location_on_rounded,
                  iconColor: AppTheme.accentOrange,
                  isLoading: _dstLoading,
                  isFirst: false,
                  onChanged: (v) { _destination = null; },
                  onSubmitted: (v) { if (v.isNotEmpty) _resolveDestination(v); },
                ),
              ]),
            ),

            const SizedBox(height: 28),

            // ── Recent / Quick picks ────────────────────────────────────────────
            Text('Quick picks', style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 13, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 8, children: [
              _QuickChip(label: 'Hospital', icon: Icons.local_hospital_outlined, onTap: () { _dstCtrl.text = 'Hospital nearby'; _destination = null; }),
              _QuickChip(label: 'Police Station', icon: Icons.local_police_outlined, onTap: () { _dstCtrl.text = 'Police Station nearby'; _destination = null; }),
              _QuickChip(label: 'Bus Stop', icon: Icons.directions_bus_outlined, onTap: () { _dstCtrl.text = 'Bus stop nearby'; _destination = null; }),
              _QuickChip(label: 'Railway', icon: Icons.train_outlined, onTap: () { _dstCtrl.text = 'Railway station nearby'; _destination = null; }),
            ]),

            const SizedBox(height: 36),

            // ── Find Routes Button ──────────────────────────────────────────────
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                onPressed: (_srcCtrl.text.isEmpty || _dstCtrl.text.isEmpty || _isLoading) ? null : _findRoutes,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.accent,
                  foregroundColor: AppTheme.primary,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  elevation: 0,
                ),
                child: _isLoading
                    ? Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5, color: AppTheme.primary)),
                        const SizedBox(width: 12),
                        Text('Finding routes…', style: GoogleFonts.spaceGrotesk(fontSize: 15, fontWeight: FontWeight.w700, color: AppTheme.primary)),
                      ])
                    : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        const Icon(Icons.alt_route_rounded, size: 22),
                        const SizedBox(width: 10),
                        Text('Find Routes', style: GoogleFonts.spaceGrotesk(fontSize: 16, fontWeight: FontWeight.w800)),
                      ]),
              ),
            ),

            const SizedBox(height: 16),

            // Area safety badge
            if (_areaSafetyScore > 0)
              Center(child: _AreaSafetyBadge(score: _areaSafetyScore)),
          ]),
        ),
      ),
    );
  }

  // ── Phase 2 : Map with routes ─────────────────────────────────────────────────
  Widget _buildMapPhase() {
    return Stack(children: [
      // ── Map ──────────────────────────────────────────────────────────────────
      FlutterMap(
        mapController: _mapController,
        options: MapOptions(
          center: _origin ?? const LatLng(AppConstants.defaultLat, AppConstants.defaultLng),
          zoom: 13,
          onLongPress: (_, latlng) => _onMapLongPress(latlng),
        ),
        children: [
          TileLayer(urlTemplate: AppConstants.mapTileUrl, userAgentPackageName: 'com.saferoute.app'),

          // ── Route polylines — unselected (dim) first ────────────────────────
          PolylineLayer(
            polylines: [
              for (int i = 0; i < _routes.length; i++)
                if (_routes[i].id != _selectedRoute?.id)
                  Polyline(
                    points:      _routes[i].points,
                    strokeWidth: 4,
                    color:       _routeColors[i % _routeColors.length].withOpacity(0.35),
                  ),
            ],
          ),

          // ── Selected route — bold on top ─────────────────────────────────────
          if (_selectedRoute != null)
            PolylineLayer(
              polylines: [
                Polyline(
                  points:      _selectedRoute!.points,
                  strokeWidth: 6.5,
                  color:       _routeColors[
                    _routes.indexWhere((r) => r.id == _selectedRoute!.id)
                        .clamp(0, _routeColors.length - 1)
                  ],
                  // Dashed-like effect: Flutter Map 3.x strokeCap
                  strokeCap: StrokeCap.round,
                  strokeJoin: StrokeJoin.round,
                ),
              ],
            ),

          // ── Safety report markers ─────────────────────────────────────────────
          MarkerLayer(
            markers: _reports.map((r) => Marker(
              point: r.location, width: 32, height: 32,
              child: HazardMarker(report: r),
            )).toList(),
          ),

          // ── Waypoint markers (A / B) ─────────────────────────────────────────
          MarkerLayer(markers: [
            if (_origin != null)
              Marker(
                point: _origin!, width: 56, height: 64,
                child: _WaypointMarker(label: 'A', color: AppTheme.safe),
              ),
            if (_destination != null)
              Marker(
                point: _destination!, width: 56, height: 64,
                child: _WaypointMarker(label: 'B', color: AppTheme.accentOrange),
              ),
          ]),

          // ── Midpoint safety score badges on each route ──────────────────────
          MarkerLayer(
            markers: [
              for (int i = 0; i < _routes.length; i++)
                if (_routes[i].points.length > 1)
                  Marker(
                    point: _routes[i].points[_routes[i].points.length ~/ 2],
                    width: 58, height: 28,
                    child: _RouteScoreBadge(
                      score: _routes[i].safetyScore,
                      color: _routeColors[i % _routeColors.length],
                      isSelected: _routes[i].id == _selectedRoute?.id,
                    ),
                  ),
            ],
          ),

          // ── Live user dot ────────────────────────────────────────────────────
          if (_currentLocation != null)
            MarkerLayer(markers: [
              Marker(point: _currentLocation!, width: 60, height: 60, child: _CurrentLocationMarker()),
            ]),
        ],
      ),

      // ── Top bar: back + search summary + nav status ──────────────────────────
      SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            // Route summary header card
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: AppTheme.cardBg.withOpacity(0.97),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppTheme.border),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 12)],
              ),
              child: Row(children: [
                // Back to search
                GestureDetector(
                  onTap: () {
                    _panelCtrl.reverse();
                    setState(() { _phase = 'search'; _showRoutePanel = false; _routes = []; _selectedRoute = null; });
                  },
                  child: Container(
                    width: 34, height: 34,
                    decoration: BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppTheme.border)),
                    child: const Icon(Icons.arrow_back_ios_new_rounded, color: AppTheme.textSecondary, size: 15),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    const Icon(Icons.radio_button_checked_rounded, color: AppTheme.safe, size: 12),
                    const SizedBox(width: 5),
                    Expanded(child: Text(_originAddress, overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.spaceGrotesk(color: AppTheme.textPrimary, fontSize: 12, fontWeight: FontWeight.w600))),
                  ]),
                  const SizedBox(height: 4),
                  Row(children: [
                    const Icon(Icons.location_on_rounded, color: AppTheme.accentOrange, size: 12),
                    const SizedBox(width: 5),
                    Expanded(child: Text(_destinationAddress, overflow: TextOverflow.ellipsis,
                        style: GoogleFonts.spaceGrotesk(color: AppTheme.textPrimary, fontSize: 12, fontWeight: FontWeight.w600))),
                  ]),
                ])),
                if (_isNavigating)
                  GestureDetector(
                    onTap: _stopNavigation,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(color: AppTheme.danger.withOpacity(0.15), borderRadius: BorderRadius.circular(8), border: Border.all(color: AppTheme.danger.withOpacity(0.5))),
                      child: Text('Stop', style: GoogleFonts.spaceGrotesk(color: AppTheme.danger, fontWeight: FontWeight.w800, fontSize: 13)),
                    ),
                  ),
              ]),
            ),

            // Loading indicator
            if (_isLoading)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(color: AppTheme.cardBg, borderRadius: BorderRadius.circular(20)),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.accent)),
                    const SizedBox(width: 8),
                    Text('Calculating routes…', style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 12)),
                  ]),
                ),
              ),
          ]),
        ),
      ),

      // ── Route selector panel (slide up) ─────────────────────────────────────
      if (_showRoutePanel && _routes.isNotEmpty)
        Positioned(
          left: 0, right: 0, bottom: 0,
          child: SlideTransition(
            position: _panelAnim,
            child: _TripleRoutePanel(
              routes:        _routes,
              selectedId:    _selectedRoute?.id,
              routeColors:   _routeColors,
              onSelect:      (r) => setState(() {
                _selectedRoute = r;
                // Re-fit to selected route
                final idx = _routes.indexWhere((x) => x.id == r.id);
                if (idx >= 0 && _routes[idx].points.isNotEmpty) {
                  _fitAllRoutes(_routes);
                }
              }),
              onStart:       _startNavigation,
              isNavigating:  _isNavigating,
            ),
          ),
        ),

      // ── FABs ─────────────────────────────────────────────────────────────────
      if (!_isNavigating)
        Positioned(
          right: 14,
          bottom: _showRoutePanel ? 330 : 80,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            _MapFAB(icon: Icons.my_location_rounded, onTap: () {
              if (_currentLocation != null) _mapController.move(_currentLocation!, 15);
            }, tooltip: 'My Location'),
            const SizedBox(height: 10),
            _MapFAB(icon: Icons.report_problem_outlined, color: AppTheme.accentOrange, onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => AddReportScreen(location: _currentLocation)));
            }, tooltip: 'Report Hazard'),
          ]),
        ),
    ]);
  }

  void _onMapLongPress(LatLng latlng) async {
    final addr = await _locationSvc.getAddressFromLatLng(latlng);
    setState(() { _destination = latlng; _destinationAddress = addr; _dstCtrl.text = addr; });
    if (_origin != null) _findRoutes();
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Triple Route Panel
// ─────────────────────────────────────────────────────────────────────────────
class _TripleRoutePanel extends StatelessWidget {
  final List<SafeRoute>  routes;
  final String?          selectedId;
  final List<Color>      routeColors;
  final ValueChanged<SafeRoute> onSelect;
  final VoidCallback     onStart;
  final bool             isNavigating;

  const _TripleRoutePanel({
    required this.routes,
    required this.selectedId,
    required this.routeColors,
    required this.onSelect,
    required this.onStart,
    required this.isNavigating,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.cardBg,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(26)),
        border: Border.all(color: AppTheme.border),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.45), blurRadius: 30, offset: const Offset(0, -8))],
      ),
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        // Handle
        Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: AppTheme.border, borderRadius: BorderRadius.circular(2)))),
        const SizedBox(height: 14),

        // Title row
        Row(children: [
          Text('Choose your route', style: GoogleFonts.spaceGrotesk(color: AppTheme.textPrimary, fontWeight: FontWeight.w700, fontSize: 16)),
          const Spacer(),
          Text('${routes.length} options', style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 12)),
        ]),
        const SizedBox(height: 14),

        // 3 route cards in a row
        Row(
          children: List.generate(routes.length, (i) {
            final r       = routes[i];
            final color   = routeColors[i % routeColors.length];
            final isSelected = r.id == selectedId;
            final safetyPct  = (r.safetyScore * 10).round(); // 0–100%

            return Expanded(
              child: GestureDetector(
                onTap: () => onSelect(r),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  margin: EdgeInsets.only(right: i < routes.length - 1 ? 8 : 0),
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                  decoration: BoxDecoration(
                    color: isSelected ? color.withOpacity(0.12) : AppTheme.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: isSelected ? color : AppTheme.border, width: isSelected ? 2 : 1),
                  ),
                  child: Column(children: [
                    // Route type icon
                    Container(
                      width: 38, height: 38,
                      decoration: BoxDecoration(
                        color: color.withOpacity(isSelected ? 0.25 : 0.1),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(_routeIcons[i % _routeIcons.length], color: color, size: 20),
                    ),
                    const SizedBox(height: 8),

                    // Label
                    Text(_routeLabels[i % _routeLabels.length],
                        style: GoogleFonts.spaceGrotesk(color: isSelected ? color : AppTheme.textPrimary, fontWeight: FontWeight.w700, fontSize: 12)),
                    const SizedBox(height: 6),

                    // Safety % ring
                    _SafetyRing(percent: safetyPct / 100, color: color, size: 52),
                    const SizedBox(height: 4),

                    Text('$safetyPct% safe',
                        style: GoogleFonts.spaceGrotesk(color: color, fontWeight: FontWeight.w800, fontSize: 11)),
                    const SizedBox(height: 8),

                    // ETA
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.access_time_rounded, color: AppTheme.textSecondary, size: 12),
                      const SizedBox(width: 3),
                      Text(_formatEta(r.durationMinutes),
                          style: GoogleFonts.spaceGrotesk(color: AppTheme.textPrimary, fontWeight: FontWeight.w700, fontSize: 12)),
                    ]),
                    const SizedBox(height: 2),

                    // Distance
                    Text('${r.distanceKm.toStringAsFixed(1)} km',
                        style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 11)),

                    // Hazard warnings
                    if (r.hazardWarnings.isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                        decoration: BoxDecoration(color: AppTheme.warning.withOpacity(0.12), borderRadius: BorderRadius.circular(6)),
                        child: Text('⚠ ${r.hazardWarnings.first}',
                            overflow: TextOverflow.ellipsis,
                            style: GoogleFonts.spaceGrotesk(color: AppTheme.warning, fontSize: 9, fontWeight: FontWeight.w600)),
                      ),
                    ],
                  ]),
                ),
              ),
            );
          }),
        ),

        const SizedBox(height: 16),

        // Start Navigation button
        SizedBox(
          width: double.infinity, height: 52,
          child: ElevatedButton.icon(
            onPressed: isNavigating ? null : onStart,
            icon: const Icon(Icons.navigation_rounded, size: 20),
            label: Text(isNavigating ? 'Navigating…' : 'Start Navigation',
                style: GoogleFonts.spaceGrotesk(fontSize: 15, fontWeight: FontWeight.w800)),
            style: ElevatedButton.styleFrom(
              backgroundColor: selectedId != null
                  ? routeColors[routes.indexWhere((r) => r.id == selectedId).clamp(0, routeColors.length - 1)]
                  : AppTheme.accent,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
        ),
      ]),
    );
  }

  String _formatEta(int mins) {
    if (mins < 60) return '${mins}m';
    return '${mins ~/ 60}h ${mins % 60}m';
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Safety Ring — circular progress for safety %
// ─────────────────────────────────────────────────────────────────────────────
class _SafetyRing extends StatelessWidget {
  final double percent; // 0.0–1.0
  final Color  color;
  final double size;
  const _SafetyRing({required this.percent, required this.color, required this.size});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size, height: size,
      child: Stack(alignment: Alignment.center, children: [
        CircularProgressIndicator(
          value: percent,
          backgroundColor: AppTheme.border,
          valueColor: AlwaysStoppedAnimation(color),
          strokeWidth: 5,
          strokeCap: StrokeCap.round,
        ),
        Text('${(percent * 100).round()}',
            style: GoogleFonts.spaceGrotesk(color: color, fontWeight: FontWeight.w900, fontSize: 13)),
      ]),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Waypoint marker with letter label  (A = origin, B = dest)
// ─────────────────────────────────────────────────────────────────────────────
class _WaypointMarker extends StatelessWidget {
  final String label;
  final Color  color;
  const _WaypointMarker({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Container(
        width: 30, height: 30,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 2.5),
          boxShadow: [BoxShadow(color: color.withOpacity(0.5), blurRadius: 10)],
        ),
        child: Center(child: Text(label, style: GoogleFonts.spaceGrotesk(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 13))),
      ),
      CustomPaint(size: const Size(2, 14), painter: _PinTailPainter(color: color)),
    ]);
  }
}

class _PinTailPainter extends CustomPainter {
  final Color color;
  const _PinTailPainter({required this.color});
  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawLine(Offset(size.width / 2, 0), Offset(size.width / 2, size.height), Paint()..color = color..strokeWidth = 2.5..strokeCap = StrokeCap.round);
  }
  @override bool shouldRepaint(_) => false;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Mid-route safety badge on map
// ─────────────────────────────────────────────────────────────────────────────
class _RouteScoreBadge extends StatelessWidget {
  final double score;
  final Color  color;
  final bool   isSelected;
  const _RouteScoreBadge({required this.score, required this.color, required this.isSelected});

  @override
  Widget build(BuildContext context) {
    if (!isSelected) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.92),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: color.withOpacity(0.4), blurRadius: 8)],
      ),
      child: Text('${(score * 10).round()}% safe',
          style: GoogleFonts.spaceGrotesk(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800)),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Location field widget
// ─────────────────────────────────────────────────────────────────────────────
class _LocationField extends StatelessWidget {
  final TextEditingController controller;
  final String    label, hint;
  final IconData  icon;
  final Color     iconColor;
  final bool      isLoading, isFirst;
  final ValueChanged<String> onChanged;
  final ValueChanged<String> onSubmitted;
  final VoidCallback? onUseGps;

  const _LocationField({
    required this.controller,
    required this.label,
    required this.hint,
    required this.icon,
    required this.iconColor,
    required this.isLoading,
    required this.isFirst,
    required this.onChanged,
    required this.onSubmitted,
    this.onUseGps,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        border: isFirst ? null : const Border(top: BorderSide(color: AppTheme.border)),
      ),
      child: Row(children: [
        Icon(icon, color: iconColor, size: 20),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 10, fontWeight: FontWeight.w600)),
          const SizedBox(height: 2),
          TextField(
            controller: controller,
            onChanged: onChanged,
            onSubmitted: onSubmitted,
            style: GoogleFonts.spaceGrotesk(color: AppTheme.textPrimary, fontSize: 14, fontWeight: FontWeight.w600),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 13),
              border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none,
              filled: false, isDense: true, contentPadding: EdgeInsets.zero,
            ),
            textInputAction: TextInputAction.search,
          ),
        ])),
        if (isLoading)
          const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.accent))
        else if (onUseGps != null)
          GestureDetector(onTap: onUseGps, child: const Icon(Icons.gps_fixed_rounded, color: AppTheme.accent, size: 20)),
      ]),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Swap button divider
// ─────────────────────────────────────────────────────────────────────────────
class _SwapDivider extends StatelessWidget {
  final VoidCallback onSwap;
  const _SwapDivider({required this.onSwap});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      const Expanded(child: Divider(color: AppTheme.border, height: 1)),
      GestureDetector(
        onTap: onSwap,
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          width: 32, height: 32,
          decoration: BoxDecoration(color: AppTheme.surface, shape: BoxShape.circle, border: Border.all(color: AppTheme.border)),
          child: const Icon(Icons.swap_vert_rounded, color: AppTheme.accent, size: 18),
        ),
      ),
      const Expanded(child: Divider(color: AppTheme.border, height: 1)),
    ]);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Quick pick chip
// ─────────────────────────────────────────────────────────────────────────────
class _QuickChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  const _QuickChip({required this.label, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: AppTheme.cardBg,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppTheme.border),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: AppTheme.accent, size: 15),
          const SizedBox(width: 6),
          Text(label, style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 12, fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Area safety badge
// ─────────────────────────────────────────────────────────────────────────────
class _AreaSafetyBadge extends StatelessWidget {
  final double score;
  const _AreaSafetyBadge({required this.score});

  @override
  Widget build(BuildContext context) {
    final color = AppConstants.safetyColor(score);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.shield_rounded, color: color, size: 16),
        const SizedBox(width: 6),
        Text('Area safety: ${score.toStringAsFixed(1)}/10',
            style: GoogleFonts.spaceGrotesk(color: color, fontWeight: FontWeight.w700, fontSize: 13)),
      ]),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Animated current location marker
// ─────────────────────────────────────────────────────────────────────────────
class _CurrentLocationMarker extends StatefulWidget {
  @override
  State<_CurrentLocationMarker> createState() => _CurrentLocationMarkerState();
}

class _CurrentLocationMarkerState extends State<_CurrentLocationMarker>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double>   _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 2));
    _anim = Tween<double>(begin: 0, end: 1).animate(_ctrl);
    _ctrl.repeat();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) => Stack(alignment: Alignment.center, children: [
        Container(
          width: 60 * _anim.value, height: 60 * _anim.value,
          decoration: BoxDecoration(shape: BoxShape.circle, color: AppTheme.accent.withOpacity(0.18 * (1 - _anim.value))),
        ),
        Container(
          width: 18, height: 18,
          decoration: BoxDecoration(
            color: AppTheme.accent, shape: BoxShape.circle,
            border: Border.all(color: Colors.white, width: 2.5),
            boxShadow: [BoxShadow(color: AppTheme.accent.withOpacity(0.5), blurRadius: 8)],
          ),
        ),
      ]),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Map FAB
// ─────────────────────────────────────────────────────────────────────────────
class _MapFAB extends StatelessWidget {
  final IconData    icon;
  final VoidCallback onTap;
  final String      tooltip;
  final Color       color;
  const _MapFAB({required this.icon, required this.onTap, required this.tooltip, this.color = AppTheme.accent});

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 48, height: 48,
          decoration: BoxDecoration(
            color: AppTheme.cardBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppTheme.border),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 8)],
          ),
          child: Icon(icon, color: color, size: 22),
        ),
      ),
    );
  }
}
