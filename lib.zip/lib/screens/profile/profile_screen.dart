// lib/screens/profile/profile_screen.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/models.dart';
import '../../services/auth_service.dart';
import '../../utils/app_theme.dart';
import '../auth/login_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _authSvc = AuthService();
  AppUser? _user;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadUser();
  }

  Future<void> _loadUser() async {
    final u = await _authSvc.getCurrentAppUser();
    if (mounted) setState(() { _user = u; _loading = false; });
  }

  Future<void> _updatePreferences(UserPreferences prefs) async {
    if (_user == null) return;
    await _authSvc.updatePreferences(_user!.uid, prefs);
    setState(() => _user = AppUser(
      uid: _user!.uid,
      name: _user!.name,
      email: _user!.email,
      photoUrl: _user!.photoUrl,
      trustedContacts: _user!.trustedContacts,
      preferences: prefs,
    ));
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        backgroundColor: AppTheme.primary,
        body: Center(child: CircularProgressIndicator(color: AppTheme.accent)),
      );
    }

    if (_user == null) {
      return Scaffold(
        backgroundColor: AppTheme.primary,
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.person_outline,
                  color: AppTheme.textSecondary, size: 64),
              const SizedBox(height: 16),
              Text('Not signed in',
                  style: GoogleFonts.spaceGrotesk(
                      color: AppTheme.textSecondary, fontSize: 16)),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () => Navigator.of(context).pushReplacement(
                    MaterialPageRoute(builder: (_) => const LoginScreen())),
                child: const Text('Sign In'),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppTheme.primary,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // Profile header
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppTheme.cardBg,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppTheme.border),
              ),
              child: Column(
                children: [
                  Container(
                    width: 72,
                    height: 72,
                    decoration: BoxDecoration(
                      color: AppTheme.accent.withOpacity(0.15),
                      shape: BoxShape.circle,
                      border: Border.all(color: AppTheme.accent, width: 2),
                    ),
                    child: Center(
                      child: Text(
                        _user!.name.isNotEmpty
                            ? _user!.name[0].toUpperCase()
                            : '?',
                        style: GoogleFonts.spaceGrotesk(
                            color: AppTheme.accent,
                            fontSize: 28,
                            fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(_user!.name,
                      style: GoogleFonts.spaceGrotesk(
                          color: AppTheme.textPrimary,
                          fontSize: 20,
                          fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Text(_user!.email,
                      style: GoogleFonts.spaceGrotesk(
                          color: AppTheme.textSecondary, fontSize: 13)),
                ],
              ),
            ),
            const SizedBox(height: 24),
            _sectionTitle('Navigation Preferences'),
            const SizedBox(height: 12),
            _PreferenceToggle(
              title: 'Avoid Dark Alleys',
              subtitle: 'Route around poorly lit areas',
              icon: Icons.nightlight_outlined,
              value: _user!.preferences.avoidDarkAlleys,
              onChanged: (v) => _updatePreferences(
                  _user!.preferences.copyWith(avoidDarkAlleys: v)),
            ),
            const SizedBox(height: 10),
            _PreferenceToggle(
              title: 'Prefer Well-Lit Routes',
              subtitle: 'Prioritize streets with good lighting',
              icon: Icons.wb_sunny_outlined,
              value: _user!.preferences.preferLitRoutes,
              onChanged: (v) => _updatePreferences(
                  _user!.preferences.copyWith(preferLitRoutes: v)),
            ),
            const SizedBox(height: 10),
            _PreferenceToggle(
              title: 'Share Location',
              subtitle: 'Share journey with trusted contacts',
              icon: Icons.share_location_outlined,
              value: _user!.preferences.shareLocationWithContacts,
              onChanged: (v) => _updatePreferences(
                  _user!.preferences.copyWith(shareLocationWithContacts: v)),
            ),
            const SizedBox(height: 24),
            _sectionTitle('Default Route Type'),
            const SizedBox(height: 12),
            Row(
              children: ['safest', 'balanced', 'fastest'].map((type) {
                final isSelected =
                    _user!.preferences.defaultRouteType == type;
                final colors = {
                  'safest': AppTheme.safe,
                  'balanced': AppTheme.accent,
                  'fastest': AppTheme.accentOrange,
                };
                final color = colors[type]!;
                return Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: GestureDetector(
                      onTap: () => _updatePreferences(
                          _user!.preferences.copyWith(defaultRouteType: type)),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 150),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? color.withOpacity(0.15)
                              : AppTheme.cardBg,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: isSelected ? color : AppTheme.border),
                        ),
                        child: Column(
                          children: [
                            Icon(
                              type == 'safest'
                                  ? Icons.shield_outlined
                                  : type == 'fastest'
                                      ? Icons.flash_on_outlined
                                      : Icons.balance_outlined,
                              color: isSelected ? color : AppTheme.textSecondary,
                              size: 22,
                            ),
                            const SizedBox(height: 6),
                            Text(
                              type[0].toUpperCase() + type.substring(1),
                              style: GoogleFonts.spaceGrotesk(
                                color: isSelected
                                    ? color
                                    : AppTheme.textSecondary,
                                fontSize: 11,
                                fontWeight: isSelected
                                    ? FontWeight.w700
                                    : FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 32),
            OutlinedButton.icon(
              onPressed: () async {
                await _authSvc.signOut();
                if (mounted) {
                  Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (_) => const LoginScreen()));
                }
              },
              icon: const Icon(Icons.logout_rounded, color: AppTheme.danger, size: 18),
              label: Text('Sign Out',
                  style: GoogleFonts.spaceGrotesk(color: AppTheme.danger)),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppTheme.danger),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String text) => Text(
        text,
        style: GoogleFonts.spaceGrotesk(
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w700,
            fontSize: 16),
      );
}

class _PreferenceToggle extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _PreferenceToggle({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.cardBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.border),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: AppTheme.accent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: AppTheme.accent, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: GoogleFonts.spaceGrotesk(
                        color: AppTheme.textPrimary,
                        fontWeight: FontWeight.w600,
                        fontSize: 13)),
                Text(subtitle,
                    style: GoogleFonts.spaceGrotesk(
                        color: AppTheme.textSecondary, fontSize: 11)),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: AppTheme.accent,
          ),
        ],
      ),
    );
  }
}
