// lib/screens/reports/add_report_screen.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:latlong2/latlong.dart';
import '../../models/models.dart';
import '../../services/safety_service.dart';
import '../../services/auth_service.dart';
import '../../utils/app_theme.dart';

class AddReportScreen extends StatefulWidget {
  final LatLng? location;
  const AddReportScreen({super.key, this.location});
  @override
  State<AddReportScreen> createState() => _AddReportScreenState();
}

class _AddReportScreenState extends State<AddReportScreen> {
  final _descCtrl = TextEditingController();
  final _safetySvc = SafetyService();
  final _authSvc = AuthService();
  String _type = 'harassment';
  double _severity = 3;
  bool _submitting = false;

  static const _types = [
    ('harassment', Icons.person_off_rounded, 'Harassment'),
    ('theft', Icons.money_off_rounded, 'Theft'),
    ('accident', Icons.car_crash_rounded, 'Accident'),
    ('lighting', Icons.lightbulb_outlined, 'Poor Lighting'),
    ('other', Icons.warning_amber_rounded, 'Other'),
  ];

  Future<void> _submit() async {
    if (widget.location == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Location not available')),
      );
      return;
    }
    setState(() => _submitting = true);
    try {
      final user = await _authSvc.getCurrentAppUser();
      final report = SafetyReport(
        id: '',
        userId: user?.uid ?? 'anonymous',
        userName: user?.name ?? 'Anonymous',
        location: widget.location!,
        type: _type,
        description: _descCtrl.text.trim(),
        severity: _severity,
        timestamp: DateTime.now(),
      );
      await _safetySvc.submitReport(report);
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Report submitted. Thank you for keeping the community safe!'),
            backgroundColor: AppTheme.safe,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: AppTheme.danger),
        );
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primary,
      appBar: AppBar(
        title: const Text('Report Hazard'),
        backgroundColor: AppTheme.primary,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.close, color: AppTheme.textSecondary),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionTitle('Incident Type'),
            const SizedBox(height: 12),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: _types.map((t) {
                final (value, icon, label) = t;
                final isSelected = _type == value;
                return GestureDetector(
                  onTap: () => setState(() => _type = value),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 150),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppTheme.accentOrange.withOpacity(0.15)
                          : AppTheme.cardBg,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isSelected
                            ? AppTheme.accentOrange
                            : AppTheme.border,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(icon,
                            color: isSelected
                                ? AppTheme.accentOrange
                                : AppTheme.textSecondary,
                            size: 18),
                        const SizedBox(width: 8),
                        Text(label,
                            style: GoogleFonts.spaceGrotesk(
                                color: isSelected
                                    ? AppTheme.accentOrange
                                    : AppTheme.textSecondary,
                                fontWeight: isSelected
                                    ? FontWeight.w700
                                    : FontWeight.w500,
                                fontSize: 13)),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 28),
            _sectionTitle('Severity'),
            const SizedBox(height: 8),
            Row(
              children: [
                Text('Low',
                    style: GoogleFonts.spaceGrotesk(
                        color: AppTheme.safe, fontSize: 12)),
                Expanded(
                  child: SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      activeTrackColor: AppTheme.accentOrange,
                      inactiveTrackColor: AppTheme.border,
                      thumbColor: AppTheme.accentOrange,
                    ),
                    child: Slider(
                      value: _severity,
                      min: 1,
                      max: 5,
                      divisions: 4,
                      label: _severity.toInt().toString(),
                      onChanged: (v) => setState(() => _severity = v),
                    ),
                  ),
                ),
                Text('High',
                    style: GoogleFonts.spaceGrotesk(
                        color: AppTheme.danger, fontSize: 12)),
              ],
            ),
            const SizedBox(height: 28),
            _sectionTitle('Description (optional)'),
            const SizedBox(height: 12),
            TextField(
              controller: _descCtrl,
              maxLines: 4,
              style: const TextStyle(color: AppTheme.textPrimary),
              decoration: const InputDecoration(
                hintText: 'Briefly describe what happened…',
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 32),
            if (widget.location != null)
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppTheme.cardBg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.border),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.location_on_outlined,
                        color: AppTheme.accent, size: 18),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Lat: ${widget.location!.latitude.toStringAsFixed(4)}, '
                        'Lng: ${widget.location!.longitude.toStringAsFixed(4)}',
                        style: GoogleFonts.spaceGrotesk(
                            color: AppTheme.textSecondary, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 28),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _submitting ? null : _submit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.accentOrange,
                  foregroundColor: Colors.white,
                ),
                child: _submitting
                    ? const CircularProgressIndicator(strokeWidth: 2)
                    : Text('Submit Report',
                        style: GoogleFonts.spaceGrotesk(
                            fontSize: 16, fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String text) => Text(
        text,
        style: GoogleFonts.spaceGrotesk(
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w700,
            fontSize: 15),
      );
}
