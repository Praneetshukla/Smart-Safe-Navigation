// lib/services/location_service.dart
import 'dart:async';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:latlong2/latlong.dart';
import 'package:permission_handler/permission_handler.dart';

class LocationService {
  static final LocationService _instance = LocationService._();
  factory LocationService() => _instance;
  LocationService._();

  StreamController<LatLng>? _locationController;
  StreamSubscription<Position>? _positionSub;
  LatLng? _lastKnown;

  LatLng? get lastKnown => _lastKnown;

  Future<bool> requestPermission() async {
    final status = await Permission.location.request();
    return status.isGranted;
  }

  Future<LatLng?> getCurrentLocation() async {
    try {
      final granted = await requestPermission();
      if (!granted) return null;

      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 10),
      );
      _lastKnown = LatLng(pos.latitude, pos.longitude);
      return _lastKnown;
    } catch (e) {
      return null;
    }
  }

  Stream<LatLng> trackLocation() {
    _locationController?.close();
    _locationController = StreamController<LatLng>.broadcast();

    const settings = LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 10,
    );

    _positionSub = Geolocator.getPositionStream(locationSettings: settings)
        .listen((pos) {
      _lastKnown = LatLng(pos.latitude, pos.longitude);
      _locationController?.add(_lastKnown!);
    });

    return _locationController!.stream;
  }

  void stopTracking() {
    _positionSub?.cancel();
    _locationController?.close();
    _positionSub = null;
    _locationController = null;
  }

  Future<String> getAddressFromLatLng(LatLng point) async {
    try {
      final placemarks =
          await placemarkFromCoordinates(point.latitude, point.longitude);
      if (placemarks.isEmpty) return 'Unknown Location';
      final p = placemarks.first;
      return [p.street, p.subLocality, p.locality]
          .where((s) => s != null && s.isNotEmpty)
          .join(', ');
    } catch (e) {
      return '${point.latitude.toStringAsFixed(4)}, ${point.longitude.toStringAsFixed(4)}';
    }
  }

  Future<LatLng?> getLatLngFromAddress(String address) async {
    try {
      final locations = await locationFromAddress(address);
      if (locations.isEmpty) return null;
      return LatLng(locations.first.latitude, locations.first.longitude);
    } catch (e) {
      return null;
    }
  }

  double distanceBetween(LatLng a, LatLng b) {
    return Geolocator.distanceBetween(
          a.latitude, a.longitude, b.latitude, b.longitude) /
        1000; // km
  }
}
