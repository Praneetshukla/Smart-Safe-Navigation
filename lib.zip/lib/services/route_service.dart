// lib/services/route_service.dart
import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import '../models/models.dart';

class RouteService {
  static const String _osrmBase = 'https://router.project-osrm.org/route/v1';

  /// Returns up to 3 routes: safest / balanced / fastest
  Future<List<SafeRoute>> getRoutes(
      LatLng origin, LatLng dest, List<SafetyReport> reports) async {

    // Fetch 3 OSRM alternatives in one call
    final rawRoutes = await _fetchOsrmAlternatives(origin, dest);

    // Build 3 typed slots
    final List<SafeRoute> result = [];

    final types  = ['safest', 'balanced', 'fastest'];
    final scores = <double>[];

    for (int i = 0; i < rawRoutes.length && i < 3; i++) {
      final (pts, distKm, durMin) = rawRoutes[i];
      final base = SafeRoute(
        id:              '${types[i]}_${DateTime.now().millisecondsSinceEpoch}',
        type:            types[i],
        points:          pts,
        distanceKm:      distKm,
        durationMinutes: durMin,
        safetyScore:     7.5,
      );
      result.add(base);
      scores.add(7.5);
    }

    // If OSRM returned fewer than 3, synthesise the missing ones
    if (rawRoutes.isNotEmpty) {
      final base = rawRoutes.first;
      while (result.length < 3) {
        final i = result.length;
        final (basePts, baseKm, baseMins) = base;
        result.add(SafeRoute(
          id:              '${types[i]}_gen',
          type:            types[i],
          points:          _offsetRoute(basePts, i * 0.0003),
          distanceKm:      baseKm  * (1 + i * 0.07),
          durationMinutes: (baseMins * (1 - i * 0.05)).ceil(),
          safetyScore:     7.5,
        ));
      }
    }

    // Apply safety scoring against community reports
    return result.map((r) => _applySafetyScore(r, reports)).toList();
  }

  /// Fetch up to 3 alternative routes from OSRM
  Future<List<(List<LatLng>, double, int)>> _fetchOsrmAlternatives(
      LatLng origin, LatLng dest) async {
    try {
      final url = '$_osrmBase/driving/'
          '${origin.longitude},${origin.latitude};'
          '${dest.longitude},${dest.latitude}'
          '?overview=full&geometries=geojson&alternatives=3&steps=false';

      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 12));
      if (res.statusCode != 200) return _fallback(origin, dest);

      final data = json.decode(res.body);
      if (data['code'] != 'Ok') return _fallback(origin, dest);

      final List routes = data['routes'] as List;
      final result = <(List<LatLng>, double, int)>[];

      for (final r in routes) {
        final coords = r['geometry']['coordinates'] as List;
        final pts = coords.map<LatLng>((c) => LatLng(c[1].toDouble(), c[0].toDouble())).toList();
        final km  = (r['distance'] as num) / 1000;
        final min = ((r['duration'] as num) / 60).ceil();
        result.add((pts, km, min));
      }
      return result;
    } catch (_) {
      return _fallback(origin, dest);
    }
  }

  List<(List<LatLng>, double, int)> _fallback(LatLng a, LatLng b) {
    final dist = _haversine(a, b);
    return [
      (_straightLine(a, b, offset: 0),       dist,          (dist * 12).ceil()),
      (_straightLine(a, b, offset: 0.0004),   dist * 1.1,   (dist * 11).ceil()),
      (_straightLine(a, b, offset: -0.0004),  dist * 1.05,  (dist * 10).ceil()),
    ];
  }

  SafeRoute _applySafetyScore(SafeRoute route, List<SafetyReport> reports) {
    if (reports.isEmpty) {
      // Differentiated default scores per type
      final defaults = {'safest': 8.8, 'balanced': 7.2, 'fastest': 5.9};
      return SafeRoute(
        id: route.id, type: route.type, points: route.points,
        distanceKm: route.distanceKm, durationMinutes: route.durationMinutes,
        safetyScore: defaults[route.type] ?? 7.5,
      );
    }

    double penalty = 0;
    final warnings = <String>[];

    for (final report in reports) {
      double minDist = double.infinity;
      for (final pt in route.points) {
        final d = _haversine(pt, report.location) * 1000; // metres
        if (d < minDist) minDist = d;
      }
      if (minDist < 400) {
        penalty += report.severity * (1 - minDist / 400);
        if (!warnings.contains(report.typeLabel)) warnings.add(report.typeLabel);
      }
    }

    // Safest type: extra penalty multiplier to push it higher when clean
    final multiplier = route.type == 'safest' ? 0.6 : route.type == 'balanced' ? 0.85 : 1.2;
    final score = (10 - penalty * multiplier).clamp(1.0, 10.0);

    return SafeRoute(
      id: route.id, type: route.type, points: route.points,
      distanceKm: route.distanceKm, durationMinutes: route.durationMinutes,
      safetyScore: score, hazardWarnings: warnings,
    );
  }

  // ── Geometry helpers ─────────────────────────────────────────────────────────
  double _haversine(LatLng a, LatLng b) {
    const R = 6371.0;
    final dLat = _rad(b.latitude  - a.latitude);
    final dLon = _rad(b.longitude - a.longitude);
    final x = sin(dLat / 2) * sin(dLat / 2) +
        cos(_rad(a.latitude)) * cos(_rad(b.latitude)) *
        sin(dLon / 2) * sin(dLon / 2);
    return R * 2 * atan2(sqrt(x), sqrt(1 - x));
  }

  double _rad(double d) => d * pi / 180;

  List<LatLng> _straightLine(LatLng a, LatLng b, {double offset = 0}) {
    const steps = 24;
    return List.generate(steps + 1, (i) {
      final t = i / steps;
      return LatLng(
        a.latitude  + (b.latitude  - a.latitude)  * t + offset,
        a.longitude + (b.longitude - a.longitude) * t,
      );
    });
  }

  /// Slightly offset an existing route laterally (for visual separation)
  List<LatLng> _offsetRoute(List<LatLng> pts, double latOffset) {
    return pts.map((p) => LatLng(p.latitude + latOffset, p.longitude)).toList();
  }
}
